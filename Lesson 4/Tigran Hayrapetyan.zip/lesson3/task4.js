let a = +prompt();
let b = 0;
let c = 0;
let string = "";
let total = '';
for (b = 0; b < a; b++){
    for(c = 0; c < a; c++) {
        string += "*";
    }
    total += string + '\n';
    string = "";
}

console.log(total)