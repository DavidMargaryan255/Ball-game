for(start = 1; start <= 8; start++) {
    if( start == 1){
        console.log(start)
    }
    if (start == 2){
        console.log((start - 1) + " " + start )
    }
    if (start == 3){
        console.log((start - 2) + " " + (start - 1) + " " + start)
    }
    if (start == 4){
        console.log((start - 3) + " " + (start - 2) + " " + (start - 1) + " " + start)
    }
    if (start == 5){
        console.log((start - 4) + " " + (start - 3) + " " + (start - 2) + " " + (start - 1) + " " + start)
    }
    if (start == 6){
        console.log((start - 5) + " " + (start - 4) + " " + (start - 3) + " " + (start - 2) + " " + (start - 1) + " " + start)
    }
    if (start == 7){
        console.log((start - 6) + " " + (start - 5) + " " + (start - 4) + " " + (start - 3) + " " + (start - 2) + " " + (start - 1) + " " + start)
    }
    if (start == 8){
        console.log((start - 7) + " " + (start - 6) + " " + (start - 5) + " " + (start - 4) + " " + (start - 3) + " " + (start - 2) + " " + (start - 1) + " " + start)
    }
}   