let request = prompt("2 + 2 * 2 = ?");
if (request != 6) {
  let answer;
  while (answer != 6) {
    answer = prompt("Wrong answer.Try again: 2 + 2 * 2 = ?");
    if (answer == 6) {
      alert("Correct");
      break;
    }
  }
} else {
  alert("Corect!");
}
