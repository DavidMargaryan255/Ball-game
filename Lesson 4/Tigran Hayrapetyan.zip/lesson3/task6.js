let a = prompt();
let k = true;
let sum = 0;
if (isNaN(a)) {
    k = false;
    console.log(" Print number ")
}
while(a / 1 >= 1 && k != false) {
    sum += a % 10;
    a = a - (a % 10);
    a = a / 10; 
}
console.log(sum)