let a = +prompt();
let b = 1;
let c = 0;
if (isNaN(a)) {
    console.log("is not number")
}
while (!isNaN(a) && b <= a) {
    if (a % b == 0) {
        c += 1;
    }
    b++;
}
if (c == 2) {
    console.log("yes");
}
if (c > 2) {
    console.log("no")
}
if (c == 1) {
    console.log("number is 1")
} 
if (a == 0) {
    console.log("number is 0")
}